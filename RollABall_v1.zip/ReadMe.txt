I was making the roll a ball Unity tutorial and my code started to work bad, the collisions didn't work. I checked every step, but all was as the web said, then I have searched for the solution in another place and finally work, but then the web crashed It was impossible to enter it.
It was today at 12AM when I finally find a solution for the problem of the collisions, then the web crashed. I decided to find another way to do it and I found this channel who have the tutorial well explained a more actual. The video do not have a solution to the issues with the colliders, but in it, you can see what she uses and copy it. It works too. Please do not lower my grade if something is missing, I really tried to do this deliverable.

Also, I do not know how to make a Release properly so I posted the hole project, if something is wrong with the release you will see that I will not change anything after the delivery.

The lik to the video: https://youtube.com/playlist?list=PLD8pFQ5A8vv6U4Sm0JKdcNGGOOZNoX2lv&si=jMV8Sz0SFJYR-bDV

Thanks Dídac Raya